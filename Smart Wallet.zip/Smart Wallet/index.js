document.querySelector('#ewallet-form').addEventListener('submit',function(e){
    e.preventDefault();         //so page does not reloads
    const type = document.querySelector('.add-type').value;
    const desc = document.querySelector('.add-description').value;
    const value = document.querySelector('.add-value').value;
    if(desc&&value.length>0){
        addItems(type,desc,value);
        resetForm(); 
    }
});

let totalBalance = 0;
let totalIncome = 0;
let expenses = 0;



function getTime(){
    const now = new Date().toLocaleTimeString('en-us',{
        day:'numeric',
        month:'short',
        hour:'2-digit',
        minute:'2-digit'
    });
    const date = now.split(',')[0].split(' ');
    const time = now.split(',')[1];
    return `${date[1]} ${date[0]},${time}`;
} 

function addItems(type,desc,value){
    const time = getTime();
    addLocalItem(desc,value,type,time);
    const newHtml = `<div class="collection">
        <div class="item">
        <div class="item-description-time">
            <div class="item-description">
                <p>${desc}</p>
            </div>
            <div class="item-time">
                <p>${time}</p>
            </div>
        </div>
        <div class="item-amount ${type==="+"?'income-amount':'expense-amount'}">
            <p>${type} ${value}</p>
        </div>
        </div>
    </div>`;
    //if-else using ternerary operator " condition?'if-result':'else-result' "
    const collection = document.querySelector('.collection');
    collection.insertAdjacentHTML('afterbegin',newHtml);
    var amount = parseInt(value);
    type === "+" ? totalBalance += amount : totalBalance -= amount;
    type === "+" ? totalIncome += amount : expenses += amount;
    updateAmount();
}



showTransactions();
function showTransactions(){
    let items = getLocalItem();
    const collection = document.querySelector('.collection');
    for (let item of items){
        const newHtml = `<div class="collection">
        <div class="item">
        <div class="item-description-time">
            <div class="item-description">
                <p>${item.desc}</p>
            </div>
            <div class="item-time">
                <p>${item.time}</p>
            </div>
        </div>
        <div class="item-amount ${item.type==="+"?'income-amount':'expense-amount'}">
            <p>${item.type} ${item.value}</p>
        </div>
        </div>
    </div>`;
    collection.insertAdjacentHTML('afterbegin',newHtml);
    var amount = parseInt(item.value);
    item.type === "+" ? totalBalance += amount : totalBalance -= amount;
    item.type === "+" ? totalIncome += amount : expenses += amount;
    updateAmount();
    }
}


function resetForm(){
        document.querySelector('.add-type').value = "+";
        document.querySelector('.add-description').value = "";
        document.querySelector('.add-value').value = "";
}



function getLocalItem(){
    let item = localStorage.getItem('items');
    if(item){
        item = JSON.parse(item);
    }else{
        item=[];
    }
    return item;
}

function addLocalItem(desc,value,type,time){
    let item = getLocalItem();
    item.push({
        desc,time,type,value
    });
    localStorage.setItem('items',JSON.stringify(item));
}


 function updateAmount(){
    document.querySelector('.balance-amount p').innerText = `${totalBalance}`;
    document.querySelector('.income-amount p').innerText = `${totalIncome}`;
    document.querySelector('.expense-amount p').innerText = `${expenses}`;
 }