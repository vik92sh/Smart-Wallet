This project is to check the current balance in our wallet
we will be able to add our incomes
also track our expenses
and check our transaction history